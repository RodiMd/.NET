﻿'Rodi Murad
'CIT 161
'make an order by taking values from a txt file and write the order on a different txt file

Imports System.IO

Public Structure ProductInfo

    Dim strProduct As String   ' to hold the products
    Dim intQuantity As Integer ' to hold the quantity
    Dim decPrice As Decimal    ' to hold the price

End Structure

Public Class Form1

    Dim intQuantity As Integer
    Dim strQuantitys(3) As String
    Dim strPrices(3) As String 'declare a string array for the prices to be available by other procedures
    Dim intCount As Integer = 0 'declare public counter integer used for loops

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        'declares a streamreader of the products.txt file
        Dim Product As New StreamReader("Products.txt")
        Dim strProducts(3) As String

        Dim ChosenProduct As ProductInfo ' structure variable

        Do Until Product.Peek = -1 'loop seeking the end of contents in txt file

            'reading the line contents in the txt file
            'and assigning it to the choseenProduct info
            ChosenProduct.strProduct = Product.ReadLine()
            ChosenProduct.intQuantity = CInt(Product.ReadLine())
            ChosenProduct.decPrice = CDec(Product.ReadLine())
            strProducts(intCount) = ChosenProduct.strProduct
            strQuantitys(intCount) = CStr(ChosenProduct.intQuantity)
            strPrices(intCount) = CStr(ChosenProduct.decPrice.ToString("c"))
            lstProduct.Items.Add(strProducts(intCount))

            intCount += 1
        Loop

        'loop to add values to combobox
        For Me.intCount = 1 To 5
            Me.cboQuantity.Items.Add(intCount.ToString)
        Next

        'disabled the possibility of event without selecting an item
        btnOrder.Enabled = False
        btnPrint.Enabled = False

        intCount = 0 ' returning the value of intcount to zero

    End Sub

    Private Sub lstProduct_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lstProduct.SelectedIndexChanged

        'declaring the strings used for the items selected
        Dim strItem1 As String, strItem2 As String, strItem3 As String, strItem4 As String

        'assing strings to indeces of the listbox
        strItem1 = lstProduct.Items(0).ToString()
        strItem2 = lstProduct.Items(1).ToString()
        strItem3 = lstProduct.Items(2).ToString()
        strItem4 = lstProduct.Items(3).ToString()

        'using select case to determine the seleciton in the listbox and to pass the associated price
        'with the selection
        Select Case lstProduct.SelectedItem.ToString

            Case Is = strItem1
                lblPrice.Text = strPrices(0)
            Case Is = strItem2
                lblPrice.Text = strPrices(1)
            Case Is = strItem3
                lblPrice.Text = strPrices(2)
            Case Is = strItem4
                lblPrice.Text = strPrices(3)
        End Select

        btnOrder.Enabled = True
    End Sub

    Private Sub btnOrder_Click(sender As Object, e As EventArgs) Handles btnOrder.Click
        'declaring a streamwriter
        Dim Products As StreamWriter

        Dim intN As Integer
        Dim decCost As Decimal
        Dim decIndPrice As Decimal

        Try
            'condition if label price box is not empty then
            If lblPrice.Text <> "" Then

                'item lblbox to contain the product selected and lblcost to contain 
                'the multiplication value of quantity selected x price of product
                lblItem.Text = CStr(lstProduct.SelectedItem)
                intQuantity = CInt(cboQuantity.Text)
                decIndPrice = CDec(lblPrice.Text)
                decCost = intQuantity * decIndPrice
                lblCost.Text = CStr(decCost.ToString("c"))
            End If

        Catch
            'catch message to choose a value in the quantity
            MessageBox.Show("please enter a value for the quantity")
            Exit Sub
        End Try

        'display an error that the user chose a larger quantity than is available
        If CStr(lstProduct.SelectedIndex) <> "" Then
            intN = lstProduct.SelectedIndex
            If CInt(cboQuantity.Text) > CInt(strQuantitys(intN)) Then
                MessageBox.Show("please enter a value that is equal or less than the quantity available")
                Exit Sub
            End If
        End If
        'adding to the file orders.txt the orders made
        Products = File.AppendText("Orders.txt")
        Products.WriteLine(lstProduct.SelectedItem)
        Products.WriteLine(decCost)

        'closing the products file
        Products.Close()

        'using the enabled button to ensure that an order cannot be done again until the print button was clicked
        btnOrder.Enabled = False
        btnPrint.Enabled = True

    End Sub

    Private Sub btnReport_Click(sender As Object, e As EventArgs) Handles btnReport.Click

        'using the even handler of a report button click to display the order in a printpreview box
        prntPrintPreview.Document = pdProductInventory
        prntPrintPreview.ShowDialog()

    End Sub

    Private Sub pdProductInventory_PrintPage(sender As Object, e As Printing.PrintPageEventArgs) Handles pdProductInventory.PrintPage
        Dim intCounter As Integer = 0
        Dim intY As Single = 310

        'showing the inventory report on a printpreview page upon a click event for the report button
        e.Graphics.DrawString("Inventory Report", New Font("", 20, FontStyle.Regular), Brushes.Black, 300, 200)
        e.Graphics.DrawString("Product" & "       Quantity" & "       Price", New Font("", 20, FontStyle.Regular), Brushes.Black, 230, 250)
        e.Graphics.DrawString("'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''", New Font("", 20, FontStyle.Regular), Brushes.Black, 220, 280)

        'goes through the loop to add all the items in the list without repeating each statement for each item
        Do Until intCounter = 4
            e.Graphics.DrawString(lstProduct.Items(intCounter).ToString(), New Font("", 15, FontStyle.Regular), Brushes.Black, 250, intY)
            e.Graphics.DrawString(strQuantitys(intCounter).ToString(), New Font("", 15, FontStyle.Regular), Brushes.Black, 410, intY)
            e.Graphics.DrawString(strPrices(intCounter).ToString(), New Font("", 15, FontStyle.Regular), Brushes.Black, 540, intY)
            intY += 30
            intCounter += 1
        Loop

    End Sub

    Private Sub btnPrint_Click(sender As Object, e As EventArgs) Handles btnPrint.Click

        'using the even handler of a report button click to display the order in a printpreview box
        prntPrintPreview.Document = pdOrder
        prntPrintPreview.ShowDialog()

    End Sub

    Private Sub pdOrder_PrintPage(sender As Object, e As Printing.PrintPageEventArgs) Handles pdOrder.PrintPage

        'show the results of the print event on a printpreview dialog
        e.Graphics.DrawString("Order", New Font("", 20, FontStyle.Regular), Brushes.Black, 300, 200)
        e.Graphics.DrawString("Product" & "        Price", New Font("", 20, FontStyle.Regular), Brushes.Black, 230, 250)
        e.Graphics.DrawString("''''''''''''''''''''''''''''''''''''''''''''''", New Font("", 20, FontStyle.Regular), Brushes.Black, 220, 280)

        e.Graphics.DrawString(lstProduct.SelectedItem.ToString(), New Font("", 20, FontStyle.Regular), Brushes.Black, 230, 310)
        e.Graphics.DrawString(lblCost.Text, New Font("", 20, FontStyle.Regular), Brushes.Black, 380, 310)

        btnPrint.Enabled = False
        lblCost.Text = String.Empty
        lblItem.Text = String.Empty

    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click

        'close application
        Me.Close()

    End Sub
End Class
